#ifndef UPDATE_BACKUP_MODULE_H
#define UPDATE_BACKUP_MODULE_H

#include "../../essentials/struct.h"

void update_backup(host *host, char *buffer);

#endif // !UPDATE_BACKUP_MODULE_H
